Thank you for using our map, we hope you enjoy it.

[File is FiveM ready]

for questions or problems join our discord server:

https://discord.gg/AQNDG7Pc6R